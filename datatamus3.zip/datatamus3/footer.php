<div class="container">
    <div class="row">
        <div class="col-xs-12">
            Copyright &COPY; <?= date('Y')?>ABC Cookies and Cake Kisaran |
            <a href="#">@Lestari</a>
            <a href="#">@Nurbaiti</a>
            <a href="#">@Yayang Sofiyani</a>
        </div>
    </div>
</div>
