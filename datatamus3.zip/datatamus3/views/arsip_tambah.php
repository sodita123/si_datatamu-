<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Form Tambah Data Tamu</h3>
                </div>
                <div class="panel-body">
                    <!--membuat form untuk tambah data-->
                    <form class="form-horizontal" action="" method="post">
                        <div class="form-group">
                            <label for="no_meja" class="col-sm-3 control-label">Nomor Meja</label>
                               <div class="col-sm-2 col-xs-9">
                                <select name="no_meja" class="form-control">
                                    <option value="pilih">---Pilih---</option>
                                    <option value="01">01</option>
                                    <option value="02">02</option>
                                    <option value="01">03</option>
                                    <option value="02">04</option>
                                    <option value="01">05</option>
                                    <option value="02">06</option>
                                    <option value="01">07</option>
                                    <option value="02">08</option>
                                    <option value="01">09</option>
                                    <option value="02">10</option>
                                </select>
                            </div>
                        </div>
						 <div class="form-group">
                            <label for="no_ant" class="col-sm-3 control-label">Nomor Antrian</label>
                            <div class="col-sm-9">
                                <input type="text" name="no_ant" class="form-control" id="inputEmail3" placeholder="Inputkan Nomor Antrian" required>
                            </div>
                        </div>
						 <div class="form-group">
                            <label for="no_hp" class="col-sm-3 control-label">Nomor Handphone</label>
                            <div class="col-sm-9">
                                <input type="text" name="no_hp" class="form-control" id="inputEmail3" placeholder="Inputkan Nomor Handphone" required>
                            </div>
                        </div>
						 <div class="form-group">
                            <label for="jlh" class="col-sm-3 control-label">Jumlah Pesanan</label>
                            <div class="col-sm-9">
                                <input type="text" name="jlh" class="form-control" id="inputEmail3" placeholder="Inputkan Jumlah Pesanan" required>
                            </div>
                        </div>
						 <div class="form-group">
                            <label for="alamat" class="col-sm-3 control-label">Alamat</label>
                            <div class="col-sm-9">
                                <input type="text" name="alamat" class="form-control" id="inputEmail3" placeholder="Inputkan Alamat Pelanggan" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="nama_pel" class="col-sm-3 control-label">Nama Pelanggan</label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_pel"class="form-control" id="inputEmail3" placeholder="Inputkan Nama Pelanggan" required>
                            </div>
                        </div>

                         <div class="form-group">
                            <label for="tgl_masuk" class="col-sm-3 control-label">Tanggal Masuk</label>
                            <div class="col-sm-3">
                                <input type="date" name="tgl_masuk" class="form-control" id="inputEmail3" placeholder="Inputkan Tanggal Masuk" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="nama_ksr" class="col-sm-3 control-label">Nama Kasir</label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_ksr" class="form-control" id="inputPassword3" placeholder="Inputkan Nama Kasir" required>
                            </div>
                        </div>
						<div class="form-group">
                            <label for="nama_pelayan" class="col-sm-3 control-label">Nama Pelayan</label>
                            <div class="col-sm-9">
                                <input type="text" name="nama_pelayan" class="form-control" id="inputPassword3" placeholder="Inputkan Nama Pelayan" required>
                            </div>
                        </div>


                        <!--Status-->

                        <div class="form-group">
                            <label for="jns_kel" class="col-sm-3 control-label">Jenis Kelamin</label>
                            <div class="col-sm-2 col-xs-9">
								<select name="jns_kel" class="form-control">
                                    <option value="pilih">---Pilih---</option>
									<option value="Perempuan">Perempuan</option>
									<option value="Laki-Laki">Laki-Laki</option>
								</select>
                            </div>
                        </div>
                        <!--Akhir Status-->

						<div class="form-group">
                            <label for="komen" class="col-sm-3 control-label">Komentar</label>
                            <div class="col-sm-9">
                                <input type="text" name="komen" class="form-control" id="inputPassword3" placeholder="Inputkan Komentar Pelanggan">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-9">
                                <button type="submit" class="btn btn-success">
                                    <span class="fa fa-save"></span> Simpan Data</button>
                            </div>
                        </div>
                    </form>


                </div>
                <div class="panel-footer">
                    <a href="?page=arsip&actions=tampil" class="btn btn-danger btn-sm">
                        Kembali Ke Data Tamu
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>

<?php
if($_POST){
    //Ambil data dari form
  $ruang=$_POST['alamat'];
	$rak=$_POST['no_meja'];
	$laci=$_POST['no_ant'];
	$boks=$_POST['no_hp'];
  $arsip=$_POST['jlh'];
	$noperkara=$_POST['nama_pel'];
  $tglmasuk=$_POST['tgl_masuk'];
  $pengantar=$_POST['nama_ksr'];
	$penerima=$_POST['nama_pelayan'];
  $status=$_POST['jns_kel'];
	$ket=$_POST['komen'];
    //buat sql
    $sql="INSERT INTO arsip VALUES ('','$ruang','$rak','$laci','$boks','$arsip','$noperkara','$tglmasuk','$penerima','$pengantar','$status','$ket')";
    $query=  mysqli_query($koneksi, $sql) or die ("SQL Simpan Arsip Error");
    if ($query){
        echo "<script>window.location.assign('?page=arsip&actions=tampil');</script>";
    }else{
        echo "<script>alert('Simpan Data Gagal');<script>";
    }
    }

?>
