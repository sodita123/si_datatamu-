<!DOCTYPE html>
<html>
    <head>
        <title>Cetak Data Semua Tamu</title>
        <link href="../Assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    </head>  
    <body onload="print()">
        <!--Menampilkan data detail arsip-->
        <?php
        include '../config/koneksi.php';
        ?>   

        <div class="container">
            <div class='row'>
                <div class="col-sm-12">
                    <!--dalam tabel--->
                    <div class="text-center">
                        <h2>Sistem Informasi Data Tamu ABC Cookies and Cake Kisaran </h2>
                        <h4>Jalan Prof M Yamin SH<br> Kisaran Barat, Kabupaten Asahan, Sumatera Utara, 21224</h4>
                        <hr>
                        <h3>DATA SELURUH TAMU</h3>
                        <table class="table table-bordered table-striped table-hover"> 
                        <tbody>
                                <thead>
								<tr>
									<th>No.</th><th width="18%">Nomor Perkara</th><th>Ruang Arsip</th><th width="14%"><center>Nomor <br> (Rak-Laci-Boks)</center></th><th width="15%"><center>Para Pihak</center></th><th width="10%">Tgl. Masuk</th><th><center>Pengantar Berkas</center></th><th><center>Penerima Berkas</center></th>
								</tr>
								</thead>
							<tbody>
                            <!--ambil data dari database, dan tampilkan kedalam tabel-->
                            <?php
                            //buat sql untuk tampilan data, gunakan kata kunci select
                            $sql = "SELECT * FROM arsip";
                            $query = mysqli_query($koneksi, $sql) or die("SQL Anda Salah");
                            //Baca hasil query dari databse, gunakan perulangan untuk 
                            //Menampilkan data lebh dari satu. disini akan digunakan
                            //while dan fungdi mysqli_fecth_array
                            //Membuat variabel untuk menampilkan nomor urut
                            $nomor = 0;
                            //Melakukan perulangan u/menampilkan data
                            while ($data = mysqli_fetch_array($query)) {
                                $nomor++; //Penambahan satu untuk nilai var nomor
                                ?>
                                <tr>
                                    <td><?= $nomor ?></td>
									<td><?= $data['nama_pel'] ?></td>
                                    <td><?= $data['no_meja'] ?></td>
                                    <td><?= $data['no_ant'] ?> - <?= $data['no_hp'] ?> - <?= $data['jlh'] ?></td>
                                    <td><?= $data['alamat'] ?></td>
									<td><?= $data['tgl_masuk'] ?></td>
									<td><?= $data['nama_ksr'] ?></td>
									<td><?= $data['nama_pelayan'] ?></td>
                                </tr>
                                <!--Tutup Perulangan data-->
                            <?php } ?>
							</tbody>
                        </tbody>
                            <tfoot> 
                                <tr>
                                    <td colspan="8" class="text-right">
                                        Kisaran  <?= date("d-m-Y") ?>
                                        <br><br><br><br>
                                        <u>Mahasiswa STMIK Royal Kisaran<strong></u><br>
                                        Tahun   : 2019
									</td>
								</tr>
							</tfoot> 
                        </table>
                    </div>
                </div>
            </div>
    </body>
</html>